/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.resource;

/**
 *
 * @author User
 */

import com.lakmindee.bookstore.model.Book;
import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.logging.Logger;

import com.lakmindee.bookstore.exception.BookNotFoundException;
import com.lakmindee.bookstore.exception.InvalidInputException;


@Path("/books")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BookResource {
    
    public static final Map<Integer, Book > books = new HashMap<>();
    private static int nextId = 1;
    private static final Logger logger = Logger.getLogger(BookResource.class.getName());
    
    //getting all the books [GET/books]
    @GET
    public Response getAllBooks() {
        logger.info("Fetching all books");
        return Response.ok(new ArrayList<>(books.values())).build();
    }
    
    
    //getting a book by Id [GET/books/{id}]
    @GET
    @Path("/{id}")
    public Response getBookById(@PathParam("id") int id) {
        
        // Validate ID
        if (id <= 0) {
            logger.warning("Invalid book ID: " + id);
            throw new InvalidInputException("Book ID must be positive");
        }
        
        Book book = books.get(id);
        if (book == null){
            logger.warning("No book found with ID: " + id);
            throw new BookNotFoundException("Book with ID" + id + "not found.");
        }
        
        logger.info("Retrieved book with ID: " + id);
        return Response.ok(book).build();
       
    }
    
    //creating a new book [POST / books]
    @POST
    public Response createBook(Book book, @Context UriInfo uriInfo) {
        
        if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
            logger.warning("Book creating failed: missing title");
            throw new InvalidInputException("Title is required");
        }
        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            logger.warning("Book creating failed: missing ISBN");
            throw new InvalidInputException("ISBN is required");
        }
        if (book.getAuthorId() <= 0) {
            logger.warning("Book creating failed: invalid author ID");
            throw new InvalidInputException("Valid author ID is required");
        }
         if (book.getPublicationYear() <= 0) {
            logger.warning("Book creating failed: invalid publication year");
            throw new InvalidInputException("Valid publication year is required");
        }
        if (book.getPrice() <= 0) {
            logger.warning("Book creating failed: invalid price");
            throw new InvalidInputException("Price must be positive");
        }
        if (book.getStock() < 0) {
            logger.warning("Book creating failed: invalid stock");
            throw new InvalidInputException("Stock cannot be negative");
        }

        //set ID and save it
        book.setId(nextId++);
        books.put(book.getId(), book);
        logger.info("Created book with ID: " + book.getId());

        // Returning 201 Created in theLocation header
        return Response.created(
            uriInfo.getAbsolutePathBuilder().path(Integer.toString(book.getId())).build()
        ).entity(book).build();
    }
    
    //updating book by Id [ PUT / books/{id}]
    @PUT
    @Path("/{id}")
    public Response updateBook(@PathParam("id") int id, Book updatedBook) {
        
        // Validate ID
        if (id <= 0) {
            logger.warning("Invalid book ID to update: " + id);
            throw new InvalidInputException("Book ID must be positive");
        }
        
        // Validate if it exists
        if (!books.containsKey(id)) {
            logger.warning("Failed to update, book not found: " + id);
            throw new BookNotFoundException("Book with ID " + id + " not found");
        }
        
        // Validate input
        if (updatedBook.getTitle() == null || updatedBook.getTitle().trim().isEmpty()) {
            throw new InvalidInputException("Title is required");
        }
        if (updatedBook.getIsbn() == null || updatedBook.getIsbn().trim().isEmpty()) {
            throw new InvalidInputException("ISBN is required");
        }
        
        //update
        updatedBook.setId(id);
        books.put(id, updatedBook);
        logger.info("Updated book with ID: " + id);
        
        return Response.ok(updatedBook).build();
    }
    
    //deleting a book by Id [DELETE / books/{id}]
    @DELETE
    @Path("/{id}")
    public Response deleteBook(@PathParam("id") int id) {
        
        // Validate ID
        if (id <= 0) {
            logger.warning("Delete attempt with invalid ID: " + id);
            throw new InvalidInputException("Book ID must be positive");
        }
        
        if (!books.containsKey(id)) {
            logger.warning("Failed to delete, book not found: " + id);
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        books.remove(id);
        logger.info("Deleted book with ID: " + id);
        
        return Response.ok()
               .entity(Map.of(
                   "status", "success",
                   "message", "Book with ID " + id + " was deleted"
               ))
               .build();
    }
    
    @DELETE
    public Response deleteAllBooks() {
        int count = books.size();
        books.clear();
        logger.info("Deleted all books (" + count + " records)");
        return Response.ok()
               .entity(Map.of(
                   "status", "success",
                   "message", "All books (" + count + ") were deleted"
               ))
               .build();
    }


}
