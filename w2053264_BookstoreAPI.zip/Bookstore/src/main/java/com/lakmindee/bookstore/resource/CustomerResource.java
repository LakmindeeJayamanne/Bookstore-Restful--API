/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.resource;

/**
 *
 * @author User
 */
import com.lakmindee.bookstore.model.Customer;
import com.lakmindee.bookstore.exception.CustomerNotFoundException;
import com.lakmindee.bookstore.exception.InvalidInputException;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.logging.Logger;

@Path("/customers")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CustomerResource {
    
    private static final Map<Integer, Customer> customers = new ConcurrentHashMap<>();
    private static int nextId =1;
    private static final Logger logger = Logger.getLogger(CustomerResource.class.getName());
    
    
    @GET
    public Response getAllCustomers() {
        logger.info("Fetching all customers");
        return Response.ok(new ArrayList<>(customers.values())).build();
    }

    @GET
    @Path("/{id}")
    public Response getCustomerById(@PathParam("id") int id) {
        // Validate ID
        if (id <= 0) {
            logger.warning("Invalid customer ID: " + id);
            throw new InvalidInputException("Customer ID must be positive");
        }
        
        Customer customer = customers.get(id);
        if (customer == null) {
            logger.warning("Customer not found with ID: " + id);
            throw new CustomerNotFoundException("Customer with ID " + id + " not found.");
        }
        logger.info("Found customer with ID: " + id);
        return Response.ok(customer).build();
            
    }
    
    @POST
     public Response createCustomer(Customer customer, @Context UriInfo uriInfo) {
         
         // Validate input fields
        if (customer.getFirstName() == null || customer.getFirstName().trim().isEmpty()) {
            logger.warning("Creating customer failed: missing first name");
            throw new InvalidInputException("First name is required");
        }
        if (customer.getEmail() == null || customer.getEmail().trim().isEmpty()) {
            logger.warning("Creating customer failed: missing email");
            throw new InvalidInputException("Email is required");
        }
        
        // Validating email format 
        if (!customer.getEmail().contains("@")) {
            logger.warning("Creating customer failed: invalid email format");
            throw new InvalidInputException("Invalid email format");
        }
        
        // Check for duplicate email
        boolean emailExists = customers.values().stream()
            .anyMatch(c -> c.getEmail().equalsIgnoreCase(customer.getEmail()));
        if (emailExists) {
            logger.warning("Customer creation failed: email already exists");
            throw new InvalidInputException("Email already registered");
        }
         
        //set ID and save a customer
        customer.setId(nextId++);
        customers.put(customer.getId(), customer);
        logger.info("Created customer with ID: " + customer.getId());
        
        // Return 201 Created with location header
        return Response.created(
            uriInfo.getAbsolutePathBuilder().path(Integer.toString(customer.getId())).build()
        ).entity(customer).build();
    }

    @PUT
    @Path("/{id}")
    public Response updateCustomer(@PathParam("id") int id, Customer updatedCustomer) {
        
        //Validate ID
        if (id <= 0) {
            logger.warning("Invalid ID for customer update: " + id);
            throw new InvalidInputException("Customer ID must be positive");
        }
        
        //checking if a customer exists
        if (!customers.containsKey(id)) {
            logger.warning("Failed to update, customer not found: " + id);
            throw new CustomerNotFoundException("Customer with ID" + id + "not found.");
        } 
        
        // Validate input fields
        if (updatedCustomer.getFirstName() == null || updatedCustomer.getFirstName().trim().isEmpty()) {
            logger.warning("Failed to update Customer: missing first name");
            throw new InvalidInputException("First name is required");
        }
        if (updatedCustomer.getEmail() == null || updatedCustomer.getEmail().trim().isEmpty()) {
            logger.warning("Failed to update customer: missing email");
            throw new InvalidInputException("Email is required");
        }
        
        // Validate email format
        if (!updatedCustomer.getEmail().contains("@")) {
            logger.warning("Failed to update customer: invalid email format");
            throw new InvalidInputException("Invalid email format");
        }
        
        // Check for duplicate emails
        boolean emailExists = customers.values().stream()
            .filter(c -> c.getId() != id)
            .anyMatch(c -> c.getEmail().equalsIgnoreCase(updatedCustomer.getEmail()));
        
         if (emailExists) {
            logger.warning("Failed to update customer: email already exists");
            throw new InvalidInputException("Email already registered to another customer");
        }
        
        // Update customer
        updatedCustomer.setId(id);
        customers.put(id, updatedCustomer);
        logger.info("Updated customer with ID: " + id);
        
        return Response.ok(updatedCustomer).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response deleteCustomer(@PathParam("id") int id) {
        // Validate ID
        if (id <= 0) {
            logger.warning("Invalid ID for customer deletion: " + id);
            throw new InvalidInputException("Customer ID must be positive");
        }
        
        // Check if customer exists
        if (!customers.containsKey(id)) {
            logger.warning("Failed to delete, customer not found: " + id);
            throw new CustomerNotFoundException("Customer with ID " + id + " not found.");
        }
        
        customers.remove(id);
        logger.info("Deleted customer with ID: " + id);
        
        return Response.ok()
               .entity(Map.of(
                   "status", "success",
                   "message", "Customer with ID " + id + " was deleted"
               ))
               .build();
    }


}
