/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.exception;



/**
 *
 * @author User
 */
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Map;

@Provider
public class BookNotFoundExceptionMapper implements ExceptionMapper<BookNotFoundException> {
 @Override
    public Response toResponse(BookNotFoundException ex) {
        
        // Structured JSON response
        Map<String, String> errorResponse = Map.of(
            "error", "Book Not Found",
            "message", ex.getMessage()  
        );
        return Response.status(Response.Status.NOT_FOUND)
                       .entity("{\"error\": \"" + ex.getMessage() + "\"}")
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }
    
}
