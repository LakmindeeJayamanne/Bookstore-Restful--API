/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.exception;

/**
 *
 * @author User
 */
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Map;

@Provider
public class AuthorNotFoundExceptionMapper implements ExceptionMapper<AuthorNotFoundException>{
    @Override
    public Response toResponse(AuthorNotFoundException ex) {
        
        // Structured JSON response
        Map<String, String> errorResponse = Map.of(
            "error", "Author Not Found",
            "message", ex.getMessage()  // e.g., "Author with ID 999 does not exist"
        );
        
        return Response.status(Response.Status.NOT_FOUND)
                       .entity(errorResponse)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }
    
}
