/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.resource;

/**
 *
 * @author User
 */
import com.lakmindee.bookstore.model.*;
import com.lakmindee.bookstore.exception.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.logging.Logger;


@Path("/customers/{customerId}/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrderResource {
    
    private static final Map<Integer, Map<Integer, Order>> orders = new ConcurrentHashMap<>();
    private static final Map<Integer, Cart> carts = CartResource.carts; 
    private static int orderIdCounter = 1;
    private static final Logger logger = Logger.getLogger(OrderResource.class.getName());

    @POST
    public Response placeOrder(
            @PathParam("customerId") int customerId,
            @Context UriInfo uriInfo) {
        
        // Validate customer ID
        if (customerId <= 0) {
            logger.warning("Invalid customer ID for ordering: " + customerId);
            throw new InvalidInputException("Customer ID must be positive");
        }

        // Get customer's cart  and validate it
        Cart cart = carts.get(customerId);
        if (cart == null || cart.getItems().isEmpty()) {
            logger.warning("Failed to place order, empty cart for customer: " + customerId);
            throw new CartNotFoundException("Cart is empty or not found for customer ID " + customerId);
        }
        
        // processing order items
        List<CartItem> items = new ArrayList<>(cart.getItems());
        double total = calculateTotalAndValidateStock(items);

        // Create and store order
        Order order = new Order(orderIdCounter++, customerId, items, total, LocalDateTime.now());
        
        //initializing the customer order map if it doesnt exit
        orders.putIfAbsent(customerId, new ConcurrentHashMap<>());
        
        //add order to customer order
        orders.get(customerId).put(order.getOrderId(), order);
        
        // Clear cart and log success
        cart.clear();
        logger.info("Order #" + order.getOrderId() + " created for customer ID: " + customerId);

        // Return response 
        return Response.created(
            uriInfo.getAbsolutePathBuilder()
                   .path(Integer.toString(order.getOrderId()))
                   .build()
        ).entity(order).build();
        
    }
    
    @GET
    public Response getCustomerOrders(@PathParam("customerId") int customerId) {
        // Validate customer ID
        if (customerId <= 0) {
            logger.warning("Invalid customer ID for order retrieval: " + customerId);
            throw new InvalidInputException("Customer ID must be positive");
        }

        Map<Integer, Order> customerOrders = orders.get(customerId);
        if (customerOrders == null || customerOrders.isEmpty()) {
            logger.warning("No orders found for customer ID: " + customerId);
            throw new OrderNotFoundException("No orders found for customer ID " + customerId);
        }

        logger.info("Retrieved " + customerOrders.size() + " orders for customer ID: " + customerId);
        return Response.ok(new ArrayList<>(customerOrders.values())).build();
    }
    
    @GET
    @Path("/{orderId}")
    public Response getOrderById(
            @PathParam("customerId") int customerId,
            @PathParam("orderId") int orderId) {
        
        // Validate IDs
        if (customerId <= 0 || orderId <= 0) {
            logger.warning("Invalid IDs for order retrieval - customer: " + customerId + ", order: " + orderId);
            throw new InvalidInputException("Customer and Order IDs must be positive");
        }

        Map<Integer, Order> customerOrders = orders.get(customerId);
        if (customerOrders == null) {
            logger.warning("No orders found for customer ID: " + customerId);
            throw new OrderNotFoundException("No orders found for customer ID " + customerId);
        }
        
        Order order = customerOrders.get(orderId);
        if (order == null) {
            logger.warning("Order not found - customer: " + customerId + ", order: " + orderId);
            throw new OrderNotFoundException("Order with ID " + orderId + " not found for customer ID " + customerId);
        }

        logger.info("Retrieved order #" + orderId + " for customer ID: " + customerId);
        return Response.ok(order).build();
    }
    
    // Helper method to calculate total and validate stock
    private double calculateTotalAndValidateStock(List<CartItem> items) {
        double total = 0;
        for (CartItem item : items) {
            Book book = item.getBook();
            if (book.getStock() < item.getQuantity()) {
                logger.warning("Insufficient stock for book ID: " + book.getId());
                throw new OutOfStockException(
                    "Only " + book.getStock() + " available for " + book.getTitle() + 
                    " (requested: " + item.getQuantity() + ")"
                );
            }
            total += book.getPrice() * item.getQuantity();
        }
        return total;
    }
}
