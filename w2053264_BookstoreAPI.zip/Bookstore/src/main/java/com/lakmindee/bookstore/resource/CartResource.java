/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.resource;

/**
 *
 * @author User
 */

import com.lakmindee.bookstore.model.*;
import com.lakmindee.bookstore.exception.*;

import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.logging.Logger;

@Path("/customers/{customerId}/cart")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CartResource {
    
    public static final Map<Integer,Cart> carts = new HashMap<>();
    private static final Logger logger = Logger.getLogger(CartResource.class.getName());
    
    
    @GET
    public Response getCart(@PathParam("customerId") int customerId) {
        
        //validate customer Id
        if (customerId <= 0) {
            logger.warning("Invalid customer ID: " + customerId);
            throw new InvalidInputException("Customer ID must be positive");
        }
       
        Cart cart = carts.get(customerId);
        if (cart == null || cart.getItems().isEmpty()){
            logger.warning("Cart not found or empty for customer ID: " + customerId);
            throw new CartNotFoundException("Cart not found or empty for customer ID " + customerId);
        }
        logger.info("Got the cart for customer ID: " + customerId);
        return Response.ok(cart).build();
    }


    
    @POST
    @Path("/items")
    public Response addItemToCart(@PathParam("customerId") int customerId, CartItem item) {

        // Validate inputs
        if (customerId <= 0) {
            logger.warning("Invalid customer ID: " + customerId);
            throw new InvalidInputException("Customer ID must be positive");
        }
        if (item == null || item.getBook() == null || item.getQuantity() <= 0) {
            logger.warning("Invalid cart item input");
            throw new InvalidInputException("Valid book and quantity are required");
        }

        // Look up the actual Book using book ID
        Book existingBook = BookResource.books.get(item.getBook().getId());
        if (existingBook == null) {
            logger.warning("Book not found with ID: " + item.getBook().getId());
            throw new BookNotFoundException("Book not found with ID " + item.getBook().getId());
        }

        // Check stock
        if (existingBook.getStock() < item.getQuantity()) {
            logger.warning("Not enough stock for book ID: " + existingBook.getId());
            throw new OutOfStockException("Only " + existingBook.getStock() + " available for " + existingBook.getTitle());
        }

        // Create cart if not exists
        Cart cart = carts.computeIfAbsent(customerId, Cart::new);

        // Add to cart using full book object
        CartItem cartItem = new CartItem(existingBook, item.getQuantity());
        cart.addItem(cartItem);

        // Update book stock
        existingBook.setStock(existingBook.getStock() - item.getQuantity());

        logger.info("Added book ID " + existingBook.getId() + " to cart for customer ID " + customerId);

        return Response.ok(cart).build();
    }

    
    @PUT
    @Path("/items/{bookId}")
    public Response updateCartItem(
            @PathParam("customerId") int customerId,
            @PathParam("bookId") int bookId,
            @QueryParam("quantity") int newQuantity) {
        
        // Validate inputs
        if (customerId <= 0 || bookId <= 0 || newQuantity <= 0) {
            logger.warning("Invalid update parameters");
            throw new InvalidInputException("Valid IDs and quantity required");
        }
        
        Cart cart = carts.get(customerId);
        if (cart == null) {
            logger.warning("Cart not found to update");
            throw new CartNotFoundException("Cart not found");
        }
        
        // Get existing item to check stock
        CartItem existingItem = cart.getItemByBookId(bookId);
        if (existingItem == null) {
            logger.warning("Item not found in cart");
            throw new CartNotFoundException("Item not found in cart");
        }
        
        Book book = existingItem.getBook();
        int stockDifference = newQuantity - existingItem.getQuantity();
        
        if (book.getStock() < stockDifference) {
            logger.warning("Insufficient stock for update");
            throw new OutOfStockException("Not enough stock available");
        }
        
        // Update quantity and stock
        existingItem.setQuantity(newQuantity);
        book.setStock(book.getStock() - stockDifference);
        
        logger.info("Updated quantity for book ID " + bookId + " in cart " + customerId);
        return Response.ok(cart).build();
    }
    
    
    @DELETE
    @Path("/items/{bookId}")
    public Response removeItemFromCart(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId) {
        
        // Validate IDs
        if (customerId <= 0 || bookId <= 0) {
            logger.warning("Invalid removal parameters");
            throw new InvalidInputException("Valid IDs required");
        }
        
        Cart cart = carts.get(customerId);
        if (cart == null) {
            logger.warning("cart not found for customer ID: " + customerId);
            throw new CartNotFoundException("Cart not found for customer ID " + customerId);
        }

        // Remove item and restore stock
        CartItem removedItem = cart.removeItemByBookId(bookId);
        if (removedItem != null) {
            removedItem.getBook().setStock(removedItem.getBook().getStock() + removedItem.getQuantity());
        }else{
            logger.warning("Item with book ID " + bookId + " not found in cart for removal");
            throw new CartNotFoundException("Item with book ID " + bookId + " not found in cart");
        }
        
        logger.info("Removed book ID " + bookId + " from cart " + customerId);
        return Response.ok(cart).build();
    }

    @DELETE
    public Response clearCart(@PathParam("customerId") int customerId) {
        
        // Validate ID
        if (customerId <= 0) {
            logger.warning("Invalid clear cart request");
            throw new InvalidInputException("Valid customer ID required");
        }
        
        Cart cart = carts.get(customerId);
        if (cart == null) {
            logger.warning("Cart not found to clear");
            throw new CartNotFoundException("Cart not found for customer ID " + customerId);
        }

        // Restore all items' stock
        cart.getItems().forEach(item -> 
            item.getBook().setStock(item.getBook().getStock() + item.getQuantity())
        );
        cart.clear();
        
        logger.info("Cleared cart for customer ID: " + customerId);
         return Response.ok()
            .entity(Map.of(
                "status", "success",
                "message", "Cart cleared successfully for customer ID " + customerId
            ))
            .build();
    }

}
