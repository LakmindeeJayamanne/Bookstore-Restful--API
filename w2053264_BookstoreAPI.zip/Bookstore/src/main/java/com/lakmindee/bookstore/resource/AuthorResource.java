/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.resource;

/**
 *
 * @author User
 */
import com.lakmindee.bookstore.model.Author;
import com.lakmindee.bookstore.model.Book;
import com.lakmindee.bookstore.exception.AuthorNotFoundException;
import com.lakmindee.bookstore.exception.InvalidInputException;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.logging.Logger;

@Path("/authors")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AuthorResource {
    
    private static final Map<Integer, Author> authors = new ConcurrentHashMap<>();
    private static int nextId = 1;
    private static final Logger logger = Logger.getLogger(AuthorResource.class.getName());
    
    @GET
    public Response getAllAuthors() {
        logger.info("Fetching all authors");
        return Response.ok(new ArrayList<>(authors.values())).build();
    }

    @GET
    @Path("/{id}")
    public Response getAuthorById(@PathParam("id") int id) {
        
        // Validate ID
        if (id <= 0) {
            logger.warning("Invalid author ID : " + id);
            throw new InvalidInputException("Author ID must be positive");
        }
        
        Author author = authors.get(id);
        if (author == null){
            logger.warning("Author not found with ID: " + id);
            throw new AuthorNotFoundException("Author with ID " + id + " not found.");
        }
        logger.info("Found author with ID: " + id);
        return Response.ok(author).build();
    }
    
    @POST
    public Response createAuthor(Author author, @Context UriInfo uriInfo){
        
        //validating required inputs
         if (author.getFirstName() == null || author.getFirstName().trim().isEmpty()) {
            logger.warning("Author creating failed: missing first name");
            throw new InvalidInputException("First name is required");
        }
        if (author.getLastName() == null || author.getLastName().trim().isEmpty()) {
            logger.warning("Author creating failed: missing last name");
            throw new InvalidInputException("Last name is required");
        }
        
        //setting the ID and saving it
        author.setId(nextId++);
        authors.put(author.getId(), author);
        logger.info("Created author with ID: " + author.getId());
        
        //Return 201 Created in the location header
        return Response.created(
            uriInfo.getAbsolutePathBuilder().path(Integer.toString(author.getId())).build()
        ).entity(author).build();
    }
    
     @PUT
    @Path("/{id}")
    public Response updateAuthor(@PathParam("id") int id, Author updatedAuthor) {
        
        //validating the ID
        if (id <= 0) {
        logger.warning("Invalid ID to update: " + id);
        throw new InvalidInputException("ID must be positive");
    }
        
        //validating weather it exists
        if (!authors.containsKey(id)) {
            logger.warning("Update failed - author not found: " + id);
            throw new AuthorNotFoundException("Author with ID " + id + " not found.");
        }
        
        // Validate input
        if (updatedAuthor.getFirstName() == null || updatedAuthor.getFirstName().trim().isEmpty()) {
            throw new InvalidInputException("First name is required");
        }
        if (updatedAuthor.getLastName() == null || updatedAuthor.getLastName().trim().isEmpty()) {
            throw new InvalidInputException("Last name is required");
        }
        
        //update
        updatedAuthor.setId(id);    
        authors.put(id, updatedAuthor);
        logger.info("Updated author with ID: " + id);
        
        return Response.ok(updatedAuthor).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAuthor(@PathParam("id") int id) {
        
        // Validate ID
        if (id <= 0) {
            logger.warning("Invalid ID for the author deletion: " + id);
            throw new InvalidInputException("Author ID must be positive");
        }
        
        if (!authors.containsKey(id)){
            logger.warning("Failed to delete, Author not found: " + id);
            throw new AuthorNotFoundException("Author with ID " + id + " not found.");
        }
        authors.remove(id);
        logger.info("Deleted author with ID: " + id);
        
        return Response.ok()
               .entity(Map.of(
                   "status", "success",
                   "message", "Author with ID " + id + " was deleted"
               ))
               .build();
    }
    
    @GET
    @Path("/{id}/books")
    public Response getBooksByAuthorId(@PathParam("id") int id) {
        
        // Adding ID validation
        if (id <= 0) {
            logger.warning("Invalid author ID to get the books: " + id);
            throw new InvalidInputException("Author ID must be positive");
        }


        // Validate if author exists
        Author author = authors.get(id);
        if (author == null) {
            logger.warning("Getting books failed, Author not found: " + id);
            throw new AuthorNotFoundException("Author with ID " + id + " not found.");
        }

        // get books by this author
        List<Book> authorBooks = new ArrayList<>();
        for (Book book : BookResource.books.values()) {
            if (book.getAuthorId() == id) {
                authorBooks.add(book);
            }
        }
        // no books is available
        if (authorBooks.isEmpty()) {
            logger.warning("No books found for author ID: " + id);
            return Response.status(Response.Status.NOT_FOUND)
                           .entity(Map.of(
                               "error", "No books found for author ID " + id
                           ))
                           .build();
        }
        
        logger.info("Fetched " + authorBooks.size() + " books for author ID: " + id);
        return Response.ok(authorBooks).build();
    }
}
    
    
    
    

