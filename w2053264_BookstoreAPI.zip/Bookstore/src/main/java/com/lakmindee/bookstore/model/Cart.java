/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.model;

/**
 *
 * @author User
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Cart {
    
    private int customerId;
    private List<CartItem> items = new ArrayList<>();
    
    public Cart(){
        
    }
    
    public Cart(int customerId){
        this.customerId = customerId;
        this.items = new ArrayList<>();
        
    }

    public int getCustomerId() {
        return customerId;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }
    
    //adding a new item while updating quantity
    public void addItem(CartItem newItem){
        
        Optional<CartItem> existingItem = items.stream()
            .filter(item -> item.getBook().getId() == newItem.getBook().getId())
            .findFirst();

        if (existingItem.isPresent()) {
            // Update quantity if item already exists
            CartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + newItem.getQuantity());
        } else {
            // Adding a  new item if it doesn't exist
            items.add(newItem);
        }
  
    }
    
    //removing a item by the book id
    public CartItem removeItemByBookId(int bookId){
         Optional<CartItem> itemToRemove = items.stream()
            .filter(item -> item.getBook().getId() == bookId)
            .findFirst();

        if (itemToRemove.isPresent()) {
            items.remove(itemToRemove.get());
            return itemToRemove.get();
        }
        return null;
    }
    
    //clearing the entire cart
    public void clear(){
        items.clear();
    }
    
    public CartItem getItemByBookId(int bookId) {
        return items.stream()
            .filter(item -> item.getBook().getId() == bookId)
            .findFirst()
            .orElse(null);
    }
    
    // Calculate total price of all items in cart
    public double getTotalPrice() {
        return items.stream()
            .mapToDouble(item -> item.getBook().getPrice() * item.getQuantity())
            .sum();
    }

}
