/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.exception;

import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import java.util.Map;

/**
 *
 * @author User
 */
@Provider
public class CustomerNotFoundExceptionMapper implements ExceptionMapper<CustomerNotFoundException>{
     @Override
    public Response toResponse(CustomerNotFoundException ex) {
        
        // Structured JSON response
        Map<String, String> errorResponse = Map.of(
            "error", "Customer Not Found",
            "message", ex.getMessage()  
        );
        
        return Response.status(Response.Status.NOT_FOUND)
                       .entity("{\"error\": \"" + ex.getMessage() + "\"}")
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }
    
}
