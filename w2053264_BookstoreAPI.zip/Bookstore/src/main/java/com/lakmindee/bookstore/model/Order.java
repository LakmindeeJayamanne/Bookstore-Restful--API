/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lakmindee.bookstore.model;

import java.util.List;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author User
 */
public class Order {
    
    private int orderId;
    private int customerId;
    private List<CartItem> items;
    private double totalAmount;
    private LocalDateTime timestamp;
    private OrderStatus status = OrderStatus.CREATED;
    
    public enum OrderStatus {
        CREATED, PROCESSING, COMPLETED, CANCELLED
    }
    public Order(){}

    public Order(LocalDateTime timestamp, OrderStatus status) {
        this.timestamp = timestamp;
        this.status = status;
    }
  
    public Order(int orderId, int customerId, List<CartItem> items, double totalAmount, LocalDateTime timestamp) {
        this();
        this.orderId = orderId;
        this.customerId = customerId;
        this.items = List.copyOf(items);
        this.totalAmount = totalAmount;
        this.timestamp = timestamp;
    }

    public int getOrderId() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public List<CartItem> getItems() {
        return List.copyOf(items);
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setItems(List<CartItem> items) {
        this.items = List.copyOf(items); //defensive coppy
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
    
    public OrderStatus getStatus(){
        return status;
    }
    
    public void setStatus(OrderStatus status){
        this.status = status;
    }
    
    // Utility methods
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return orderId == order.orderId && 
               customerId == order.customerId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, customerId);
    }
    
    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", customerId=" + customerId +
                ", itemCount=" + (items != null ? items.size() : 0) +
                ", totalAmount=" + totalAmount +
                ", timestamp=" + timestamp +
                ", status=" + status +
                '}';
    }
    
    
       
}
